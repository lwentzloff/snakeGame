public class SnakeGame {

    public static void main(String[] args){

        new GameFrame(); //declares GameFrame from GameFrame class
    }
}
