import javax.swing.*;

public class GameFrame extends JFrame {

    GameFrame(){

        GamePanel panel = new GamePanel(); //declares GamePanel from GamePanel class
        this.add(panel);
        this.setTitle("Snake"); //title of the opened window
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
}
